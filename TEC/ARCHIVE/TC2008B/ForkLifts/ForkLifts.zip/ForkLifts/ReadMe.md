# Reto

Este es el codigo para realizar la base del Reto

## Instruccciones

Para ejecutar el codigo asi:

```bash
python Main.py Simulacion --lifters 3 --Basuras 100 --Delta 0.5
```
